import socket
import json
import scapy.all as scapy
import argparse
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import List, Tuple, Dict

# Setup logging to provide debug information
logging.basicConfig(level=logging.DEBUG)

def perform_icmp_ping_sweep(start_ip: str, end_ip: str) -> List[str]:
    """ Perform ICMP Ping Sweep to discover active hosts within a specified IP range """
    active_hosts = []  # List to store active hosts
    start_ip_parts = list(map(int, start_ip.split('.')))  # Split start IP into parts and convert to integers
    end_ip_parts = list(map(int, end_ip.split('.')))  # Split end IP into parts and convert to integers

    # Iterate through the last octet in the range of IP addresses
    for last_octet in range(start_ip_parts[3], end_ip_parts[3] + 1):
        ip_address = f"{start_ip_parts[0]}.{start_ip_parts[1]}.{start_ip_parts[2]}.{last_octet}"  # Construct IP address
        packet = scapy.IP(dst=ip_address)/scapy.ICMP()  # Create ICMP packet
        response = scapy.sr1(packet, timeout=1, verbose=0)  # Send packet and wait for response
        if response and response.haslayer(scapy.ICMP) and response[scapy.ICMP].type == 0:
            logging.debug(f"Host {ip_address} is active")  # Log active host
            active_hosts.append(ip_address)  # Add active host to list
        else:
            logging.debug(f"Host {ip_address} is not responsive")  # Log inactive host
    return active_hosts

def scan_port(port: int, host: str, protocol: str) -> Tuple[int, str, bool]:
    """ Scan a specific port for a given protocol """
    logging.debug(f"Scanning {protocol} port {port} on {host}")  # Log scanning attempt
    try:
        if protocol == 'TCP':
            # Create SYN packet to scan TCP port
            packet = scapy.IP(dst=host)/scapy.TCP(dport=port, flags='S')
            response = scapy.sr1(packet, timeout=2, verbose=0)  # Send packet and wait for response
            if response and response.haslayer(scapy.TCP) and response[scapy.TCP].flags == 'SA':
                logging.debug(f"TCP port {port} is open")  # Log open port
                return (port, 'TCP', True)
            else:
                logging.debug(f"TCP port {port} is closed or no response")  # Log closed or unresponsive port
                return (port, 'TCP', False)
        elif protocol == 'UDP':
            # Create UDP packet to scan UDP port
            packet = scapy.IP(dst=host)/scapy.UDP(dport=port)
            response = scapy.sr1(packet, timeout=2, verbose=0)  # Send packet and wait for response
            if response is None:
                logging.debug(f"UDP port {port} is open or filtered (no response)")  # Log open or filtered port
                return (port, 'UDP', True)
            else:
                logging.debug(f"UDP port {port} is closed (received response)")  # Log closed port
                return (port, 'UDP', False)
    except Exception as e:
        logging.error(f"Error scanning {protocol} port {port}: {e}")  # Log any exceptions
        return (port, protocol, False)

def perform_port_scanning(host: str, ports: List[int], protocol: str) -> List[Tuple[int, str, bool]]:
    """ Perform port scanning for a given protocol """
    results = []  # List to store results
    try:
        with ThreadPoolExecutor(max_workers=5) as executor:  # Use thread pool for concurrent scanning
            if protocol == 'TCP' or protocol == 'UDP':
                # Perform scanning using multiple threads
                results = list(executor.map(lambda port: scan_port(port, host, protocol), ports))
            else:
                print("Unsupported protocol. Please use 'TCP' or 'UDP'.")  # Handle unsupported protocols
    except KeyboardInterrupt:
        print("Scanning interrupted by user.")  # Handle user interruption
    return results

def grab_banner(host: str, port: int) -> str:
    """ Retrieve service banner from an open port """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(2)  # Set timeout for socket connection
            s.connect((host, port))  # Connect to the host and port
            s.send(b'HEAD / HTTP/1.1\r\nHost: ' + host.encode() + b'\r\n\r\n')  # Send HTTP request
            banner = s.recv(1024).decode().strip()  # Receive and decode banner information
            return banner
    except Exception as e:
        logging.error(f"Error grabbing banner on port {port}: {e}")  # Log any exceptions
        return "No banner"

def basic_vulnerability_check(banner: str) -> str:
    """ Perform a basic check on banners for known vulnerabilities """
    # Example check for a specific vulnerable version
    if "Apache/2.4.1" in banner:
        return "Vulnerable to CVE-XXXX-YYYY"
    return "No known vulnerabilities"

def os_fingerprint(host: str) -> str:
    """ Guess the OS based on TTL values or service responses """
    try:
        packet = scapy.IP(dst=host)/scapy.ICMP()  # Create ICMP packet
        response = scapy.sr1(packet, timeout=2, verbose=0)  # Send packet and wait for response
        if response:
            ttl = response[scapy.IP].ttl  # Get TTL value from response
            if ttl <= 64:
                return "Likely Linux"
            elif ttl <= 128:
                return "Likely Windows"
            else:
                return "Unknown OS"
    except Exception as e:
        logging.error(f"Error performing OS fingerprinting: {e}")  # Log any exceptions
    return "Unknown OS"

def export_results(results: List[Dict], format: str, filename: str):
    """ Export scan results to a file in specified format """
    try:
        if format == 'json':
            with open(filename, 'w') as f:
                json.dump(results, f, indent=4)  # Write results as JSON
        elif format == 'txt':
            with open(filename, 'w') as f:
                for result in results:
                    f.write(f"{result}\n")  # Write results as plain text
        else:
            print("Unsupported format. Please use 'txt' or 'json'.")  # Handle unsupported formats
    except Exception as e:
        logging.error(f"Error exporting results: {e}")  # Log any exceptions

def main():
    parser = argparse.ArgumentParser(description="ScanNinja: A Network Scanning Tool")
    parser.add_argument('--network', help="Network to scan for active hosts in the format start_ip-end_ip (e.g., 192.168.0.100-192.168.0.120)")
    parser.add_argument('--tcp-ports', default="80,443,22,21", help="Comma-separated list of TCP ports to scan")
    parser.add_argument('--udp-ports', default="53,67,123,514", help="Comma-separated list of UDP ports to scan")
    parser.add_argument('--output', default="results.json", help="Output file name")
    parser.add_argument('--format', choices=['txt', 'json'], default='json', help="Output format")
    args = parser.parse_args()

    if args.network:
        start_ip, end_ip = args.network.split('-')
        print(f"Performing network discovery from {start_ip} to {end_ip}...")
        active_hosts = perform_icmp_ping_sweep(start_ip, end_ip)  # Discover active hosts

        results = []
        for host in active_hosts:
            print(f"Scanning TCP ports on {host}...")
            tcp_ports = list(map(int, args.tcp_ports.split(',')))  # Parse TCP ports
            tcp_results = perform_port_scanning(host, tcp_ports, 'TCP')  # Scan TCP ports
            print(f"Scanning UDP ports on {host}...")
            udp_ports = list(map(int, args.udp_ports.split(',')))  # Parse UDP ports
            udp_results = perform_port_scanning(host, udp_ports, 'UDP')  # Scan UDP ports

            for port, protocol, is_open in tcp_results + udp_results:
                status = "Open" if is_open else "Closed"  # Determine port status
                banner = grab_banner(host, port) if is_open else "No banner"  # Get banner if port is open
                vulnerability = basic_vulnerability_check(banner)  # Check for vulnerabilities
                os = os_fingerprint(host)  # Perform OS fingerprinting
                results.append({
                    'host': host,
                    'port': port,
                    'protocol': protocol,
                    'status': status,
                    'banner': banner,
                    'vulnerability': vulnerability,
                    'os': os
                })

        export_results(results, args.format, args.output)  # Export results to file
        print(f"Results exported to {args.output}")

if __name__ ==
