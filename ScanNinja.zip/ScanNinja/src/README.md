Description: Documentation file explaining the tool, its features, installation, and usage.

# ScanNinja.py

**ScanNinja.py** is a beginner-friendly network enumeration and scanning tool developed to help users perform network discovery, port scanning, banner grabbing, and more. This guide provides instructions on how to install, configure, and use the tool effectively.

## Features
- **Network Discovery**: Identify active hosts using ICMP ping sweep.
- **Port Scanning**: Scan specified ports to determine their status.
- **Banner Grabbing**: Retrieve basic service information from open ports.
- **Vulnerability Checks**: Perform basic checks for known vulnerabilities.
- **Simple OS Fingerprinting**: Gather OS-related information.
- **Export Results**: Save results in `results.txt` or `results.json` format.

## Installation

### Prerequisites
- Python 3.12.4 (or later)
- Dependencies (can be installed via `pip`)

### Steps:
1. **Clone the Repository** (or download the tool):
   ```bash
   git clone https://github.com/your-repo/ScanNinja.git
