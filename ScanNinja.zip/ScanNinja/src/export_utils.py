import json

def export_results(results, output_file, output_format):
    if output_format == 'json':
        with open(output_file, 'w') as f:
            json.dump(results, f, indent=4)
    elif output_format == 'txt':
        with open(output_file, 'w') as f:
            for result in results:
                f.write(f"Host: {result['host']}\n")
                f.write(f"Port: {result['port']}\n")
                f.write(f"Protocol: {result['protocol']}\n")
                f.write(f"Status: {result['status']}\n")
                f.write(f"Banner: {result['banner']}\n")
                f.write(f"Vulnerability: {result['vulnerability']}\n")
                f.write(f"OS: {result['os']}\n")
                f.write("\n")
